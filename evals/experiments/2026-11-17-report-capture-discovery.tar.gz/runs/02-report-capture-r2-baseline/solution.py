"""Report-generation adapter: capture a command's output within a deadline."""

import asyncio
import os
import signal
from collections.abc import Sequence
from contextlib import suppress


async def capture_report(
    argv: Sequence[str], *, timeout_seconds: float, output_limit_bytes: int
) -> bytes:
    if timeout_seconds <= 0 or output_limit_bytes < 0:
        raise ValueError("invalid report budget")
    start_task = asyncio.create_task(
        asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
    )

    async def cleanup() -> None:
        try:
            process = await start_task
        except Exception:
            return
        # The group can outlive its leader, so do not check returncode first.
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
        try:
            # Drain without retaining data so a paused pipe cannot block wait().
            while await process.stdout.read(65536):
                pass
        finally:
            await process.wait()

    try:
        async with asyncio.timeout(timeout_seconds):
            # Keep ownership even if cancellation arrives during process creation.
            process = await asyncio.shield(start_task)
            output = bytearray()
            while chunk := await process.stdout.read(
                min(65536, output_limit_bytes - len(output) + 1)
            ):
                if len(output) + len(chunk) > output_limit_bytes:
                    raise ValueError("report output too large")
                output.extend(chunk)
            await process.wait()
            if process.returncode != 0:
                raise RuntimeError("report generator failed")
            return bytes(output)
    finally:
        cleanup_task = asyncio.create_task(cleanup())
        cancellation = None
        while not cleanup_task.done():
            try:
                await asyncio.shield(cleanup_task)
            except asyncio.CancelledError as exc:
                cancellation = exc
        cleanup_task.result()
        if cancellation is not None:
            raise cancellation
