"""Report-generation adapter: capture a command's output within a deadline."""

import asyncio
import os
import signal
from collections.abc import Sequence
from contextlib import suppress


async def _cleanup_report(start_task: asyncio.Task) -> None:
    # Startup is shielded so cancellation cannot lose an already-started child.
    try:
        process = await start_task
    except Exception:
        return
    with suppress(ProcessLookupError):
        os.killpg(process.pid, signal.SIGKILL)
    try:
        # Drain even after killing: a paused pipe transport can hold wait() open.
        while await process.stdout.read(65536):
            pass
    finally:
        await process.wait()


async def capture_report(
    argv: Sequence[str], *, timeout_seconds: float, output_limit_bytes: int
) -> bytes:
    if timeout_seconds <= 0 or output_limit_bytes < 0:
        raise ValueError("invalid report budget")
    start_task = asyncio.create_task(
        asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
    )
    try:
        async with asyncio.timeout(timeout_seconds):
            process = await asyncio.shield(start_task)
            output = bytearray()
            while True:
                chunk = await process.stdout.read(
                    min(65536, output_limit_bytes - len(output) + 1)
                )
                if not chunk:
                    break
                output.extend(chunk)
                if len(output) > output_limit_bytes:
                    raise ValueError("report output too large")
            if await process.wait() != 0:
                raise RuntimeError("report generator failed")
            return bytes(output)
    finally:
        cleanup = asyncio.create_task(_cleanup_report(start_task))
        cancellation = None
        while not cleanup.done():
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError as exc:
                cancellation = exc
        cleanup.result()
        if cancellation is not None:
            raise cancellation
