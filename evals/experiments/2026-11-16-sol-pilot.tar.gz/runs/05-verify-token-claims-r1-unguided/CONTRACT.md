# Task contract

`verify_token(token,key)`: HS256 only, issuer https://issuer.example, audience backend; require exp/iss/aud/sub and validate expiration.

Public signature:
    def verify_token(token: str | bytes, key: str | bytes) -> dict[str, object]
PyJWT >=2.10,<3 is installed. The key is a trusted HS256 secret. Return decoded claims
only after authenticating the signature and checking the fixed policy. Use PyJWT's
standard exceptions for invalid signatures, algorithms, issuer, audience, expiry
and missing required claims. Do not access a network or environment configuration.
