"""Authenticate tokens using the fixed backend JWT policy."""

from typing import cast

import jwt


def verify_token(token: str | bytes, key: str | bytes) -> dict[str, object]:
    """Return verified claims, propagating PyJWT validation exceptions."""
    return cast(
        dict[str, object],
        jwt.decode(
            token,
            key,
            algorithms=["HS256"],
            issuer="https://issuer.example",
            audience="backend",
            options={"require": ["exp", "iss", "aud", "sub"]},
        ),
    )
