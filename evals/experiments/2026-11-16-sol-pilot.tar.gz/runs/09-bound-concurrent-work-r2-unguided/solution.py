"""Bounded concurrent consumption of caller-owned asynchronous streams."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable


async def consume_bounded[T](
    source: AsyncIterable[T],
    handle: Callable[[T], Awaitable[None]],
    *,
    concurrency: int,
    buffer_size: int,
) -> None:
    """Consume a stream with bounded buffering and cooperative task cleanup."""
    if concurrency <= 0 or buffer_size <= 0:
        raise ValueError("concurrency and buffer_size must be positive")

    # Wrap payloads so that None can independently mark the end of the stream.
    queue: asyncio.Queue[tuple[T] | None] = asyncio.Queue(maxsize=buffer_size)

    async def produce() -> None:
        async for item in source:
            # At most one produced item is held outside the queue by this task.
            await queue.put((item,))
        for _ in range(concurrency):
            await queue.put(None)

    async def work() -> None:
        while True:
            entry = await queue.get()
            if entry is None:
                return
            await handle(entry[0])

    # Any failure cancels sibling tasks; exiting waits for their cleanup.
    async with asyncio.TaskGroup() as group:
        group.create_task(produce())
        for _ in range(concurrency):
            group.create_task(work())
