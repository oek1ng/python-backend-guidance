"""Share in-flight asynchronous loads without caching their results."""

import asyncio
from collections.abc import Callable, Coroutine, Hashable


class SingleFlight[K: Hashable, V]:
    """Own shared loader tasks on a single event loop."""

    def __init__(self) -> None:
        self.tasks: dict[K, asyncio.Task[V]] = {}

    async def get(
        self, key: K, load: Callable[[], Coroutine[object, object, V]]
    ) -> V:
        task = self.tasks.get(key)
        if task is None or task.done():
            async def run() -> V:
                return await load()

            task = asyncio.create_task(run())
            self.tasks[key] = task

            def finished(done: asyncio.Task[V]) -> None:
                # A newer load may already have replaced this completed task.
                if self.tasks.get(key) is done:
                    del self.tasks[key]
                # Observe errors even if all waiters have been cancelled.
                if not done.cancelled():
                    done.exception()

            task.add_done_callback(finished)

        return await asyncio.shield(task)

    async def close(self) -> None:
        """Cancel outstanding loads and wait for their cooperative cleanup."""
        tasks = list(self.tasks.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
