"""Share concurrent loads without caching their completed results."""

import asyncio
from collections.abc import Callable, Coroutine, Hashable


class SingleFlight[K: Hashable, V]:
    """Coalesce same-key loads within a single event loop."""

    def __init__(self) -> None:
        self._inflight: dict[K, asyncio.Task[V]] = {}

    async def get(
        self, key: K, load: Callable[[], Coroutine[object, object, V]]
    ) -> V:
        task = self._inflight.get(key)
        if task is None or task.done():
            task = asyncio.create_task(load())
            self._inflight[key] = task

            def finished(completed: asyncio.Task[V]) -> None:
                if self._inflight.get(key) is completed:
                    del self._inflight[key]
                # Observe failures even when all waiters have been cancelled.
                # Retrieving an exception does not prevent waiters receiving it.
                if not completed.cancelled():
                    completed.exception()

            task.add_done_callback(finished)

        # Cancellation belongs to the waiter, not to the shared loader.
        return await asyncio.shield(task)

    async def close(self) -> None:
        """Drain all outstanding loaders, including their async cleanup."""
        tasks = tuple(self._inflight.values())
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
