# Task contract

`SingleFlight` with async get(key,load)/close(): one in-flight loader per key, waiter cancellation does not cancel another waiter's work, failed loads can be retried, close joins owned tasks and their cooperative cleanup.

Public interface:
    class SingleFlight[K: Hashable, V]:
        def __init__(self) -> None: ...
        async def get(self, key: K, load: Callable[[], Coroutine[object, object, V]]) -> V: ...
        async def close(self) -> None: ...
Use only the Python standard library. One instance belongs to one event loop.
The helper shares in-flight loads, not completed cached values. Propagate loader
errors to waiters, and allow a later get to retry a failed load. Callers stop new
admission before close; loaders have their own deadlines and do not recursively
request their own key. close may cancel or drain work, but must join all owned
tasks and their cooperative cleanup before returning.
