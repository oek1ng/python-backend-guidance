"""Bounded concurrent consumption of caller-owned asynchronous streams."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable
from typing import cast


async def consume_bounded[T](
    source: AsyncIterable[T],
    handle: Callable[[T], Awaitable[None]],
    *,
    concurrency: int,
    buffer_size: int,
) -> None:
    """Consume with bounded buffering and cooperative structured cleanup.

    The source and any resources used by the handler remain caller-owned.
    Failures may propagate as an exception group.
    """
    if concurrency <= 0 or buffer_size <= 0:
        raise ValueError("concurrency and buffer_size must be positive")

    stop = object()
    queue: asyncio.Queue[T | object] = asyncio.Queue(maxsize=buffer_size)

    async def produce() -> None:
        async for item in source:
            # At most one input item is held here outside the bounded queue.
            await queue.put(item)
        for _ in range(concurrency):
            await queue.put(stop)

    async def work() -> None:
        while True:
            item = await queue.get()
            if item is stop:
                return
            await handle(cast(T, item))

    async with asyncio.TaskGroup() as group:
        for _ in range(concurrency):
            group.create_task(work())
        group.create_task(produce())
