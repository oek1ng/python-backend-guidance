"""Verify tokens against the fixed backend authentication policy."""

import jwt


def verify_token(token: str | bytes, key: str | bytes) -> dict[str, object]:
    """Authenticate an HS256 token and validate its required claims."""
    return jwt.decode(
        token,
        key,
        algorithms=["HS256"],
        issuer="https://issuer.example",
        audience="backend",
        options={"require": ["exp", "iss", "aud", "sub"]},
    )
