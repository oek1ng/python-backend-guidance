"""Share concurrent asynchronous loads without caching completed results."""

import asyncio
from collections.abc import Callable, Coroutine, Hashable


class SingleFlight[K: Hashable, V]:
    """Coalesce loads by key within a single event loop."""

    def __init__(self) -> None:
        self._loads: dict[K, asyncio.Task[V]] = {}
        self._closed: bool = False
        self._closing: asyncio.Task[None] | None = None

    async def get(
        self, key: K, load: Callable[[], Coroutine[object, object, V]]
    ) -> V:
        """Join the current load, or start one if no load is active."""
        if self._closed:
            raise RuntimeError("SingleFlight is closed")

        task = self._loads.get(key)
        if task is None or task.done():
            task = asyncio.create_task(self._run(load))
            self._loads[key] = task

            def finished(completed: asyncio.Task[V]) -> None:
                if self._loads.get(key) is completed:
                    del self._loads[key]
                # A load can fail after every waiter has been cancelled.
                # Retrieve its exception even when nobody remains to await it.
                if not completed.cancelled():
                    completed.exception()

            task.add_done_callback(finished)

        return await asyncio.shield(task)

    async def _run(
        self, load: Callable[[], Coroutine[object, object, V]]
    ) -> V:
        return await load()

    async def _finish_close(self, tasks: tuple[asyncio.Task[V], ...]) -> None:
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def close(self) -> None:
        """Cancel active loads and wait for their cooperative cleanup."""
        if self._closing is None:
            self._closed = True
            self._closing = asyncio.create_task(
                self._finish_close(tuple(self._loads.values()))
            )

        closing = self._closing
        cancellation: asyncio.CancelledError | None = None
        # Cancellation of a closer must not abandon the tasks it owns.
        # Concurrent closers share this join and do not cancel loads twice.
        while not closing.done():
            try:
                await asyncio.shield(closing)
            except asyncio.CancelledError as exc:
                cancellation = exc

        closing.result()
        if cancellation is not None:
            raise cancellation
