"""JWT verification with a fixed HS256 trust policy."""

import jwt


def verify_token(token: str | bytes, key: str | bytes) -> dict[str, object]:
    """Authenticate a token and validate its required claims."""
    return jwt.decode(
        token,
        key,
        algorithms=["HS256"],
        issuer="https://issuer.example",
        audience="backend",
        options={"require": ["exp", "iss", "aud", "sub"]},
    )
