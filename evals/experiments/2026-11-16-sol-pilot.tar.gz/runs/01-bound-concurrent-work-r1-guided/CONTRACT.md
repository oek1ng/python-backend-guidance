# Task contract

`await consume_bounded(source, handle, *, concurrency, buffer_size)`: process a large async input stream without unbounded pending work. Both limits must be positive; input may include `None`. Permit concurrent handlers when work is available; no more than `concurrency` active handlers and `concurrency + buffer_size + 1` produced-but-unfinished items when handlers are blocked, including a producer-held item. Return after completion or failure and cooperative cleanup; source/handler errors propagate directly or in an exception group, and cancellation leaves no active handlers. Ordering is not required. Python 3.12+ stdlib only, no framework dependency; source and shared clients remain caller-owned, with no durable-delivery guarantee.

Public signature:
    async def consume_bounded[T](
        source: AsyncIterable[T], handle: Callable[[T], Awaitable[None]],
        *, concurrency: int, buffer_size: int,
    ) -> None
Use only the Python standard library. Invalid nonpositive limits raise ValueError
with a message containing "must be positive", before source or handler work begins.
Both source and handler are cooperative with asyncio cancellation. Never close the
caller-owned source. Both direct and grouped ordinary failures are acceptable.
