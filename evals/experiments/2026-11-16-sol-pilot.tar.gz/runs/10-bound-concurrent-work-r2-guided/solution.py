"""Bounded concurrent processing of an asynchronous input stream."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable


async def consume_bounded[T](
    source: AsyncIterable[T],
    handle: Callable[[T], Awaitable[None]],
    *,
    concurrency: int,
    buffer_size: int,
) -> None:
    """Process input with bounded workers and buffering, without closing source."""
    if concurrency <= 0 or buffer_size <= 0:
        raise ValueError("concurrency and buffer_size must be positive")

    # Wrapping payloads keeps None available as a private stop marker.
    queue: asyncio.Queue[tuple[T] | None] = asyncio.Queue(maxsize=buffer_size)

    async def worker() -> None:
        while True:
            entry = await queue.get()
            if entry is None:
                return
            await handle(entry[0])

    async with asyncio.TaskGroup() as group:
        for _ in range(concurrency):
            group.create_task(worker())

        async for item in source:
            await queue.put((item,))

        for _ in range(concurrency):
            await queue.put(None)
