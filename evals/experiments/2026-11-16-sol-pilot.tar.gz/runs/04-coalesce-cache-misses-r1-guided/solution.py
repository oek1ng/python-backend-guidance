"""Share in-flight asyncio loads without caching their completed results."""

import asyncio
from collections.abc import Callable, Coroutine, Hashable


class SingleFlight[K: Hashable, V]:
    def __init__(self) -> None:
        self._tasks: dict[K, asyncio.Task[V]] = {}
        self._close_task: asyncio.Task[None] | None = None

    async def get(
        self, key: K, load: Callable[[], Coroutine[object, object, V]]
    ) -> V:
        if self._close_task is not None:
            raise RuntimeError("SingleFlight is closing or closed")

        task = self._tasks.get(key)
        # Done callbacks may not have run yet; completed values are not cached.
        if task is None or task.done():
            task = asyncio.create_task(load())
            self._tasks[key] = task

            def finished(done: asyncio.Task[V]) -> None:
                # An older callback must not remove a replacement load.
                if self._tasks.get(key) is done:
                    del self._tasks[key]
                # Retrieve failures even if every waiter has been cancelled.
                if not done.cancelled():
                    done.exception()

            task.add_done_callback(finished)

        return await asyncio.shield(task)

    async def close(self) -> None:
        """Cancel owned loads and join their cooperative cleanup."""
        if self._close_task is None:
            self._close_task = asyncio.create_task(self._shutdown())
        # Concurrent or cancelled close callers must not repeatedly cancel
        # loaders while those loaders are performing asynchronous cleanup.
        await asyncio.shield(self._close_task)

    async def _shutdown(self) -> None:
        tasks = list(self._tasks.values())
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
