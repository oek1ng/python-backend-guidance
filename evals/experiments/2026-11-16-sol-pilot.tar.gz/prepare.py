"""Prepare the approved twelve-run, direct-guide pilot without calling a model."""

import hashlib
import json
import random
import shutil
from pathlib import Path

ROOT = Path("/home/yuwisasha/python-backend-guidance")
OUT = Path(__file__).parent
MODEL = "openai/gpt-6.1-sol#medium"
TASKS = (
    "verify-token-claims",
    "bound-concurrent-work",
    "coalesce-cache-misses",
)
SYSTEM = """You are implementing a small Python module from a public behavioral contract.
Read CONTRACT.md and GUIDANCE.md, then create solution.py with the complete implementation.
Use the read and patch tools. Only solution.py may be edited.
This is a noninteractive evaluation: make reasonable implementation decisions and finish.
Verification is performed separately after your run. Shell execution, other directories,
network tools, skills and subagents are unavailable in this evaluation.
Do not claim to have run tests. Your final response should briefly describe the implementation.
"""
PROMPT = """Implement the task specified in CONTRACT.md as solution.py.
Read GUIDANCE.md for any supporting material supplied for this run.
Satisfy the observable contract; no particular implementation algorithm is required.
Write complete Python 3.12+ type annotations. Keep the solution self-contained.
"""
DETAILS = {
    "verify-token-claims": """
Public signature:
    def verify_token(token: str | bytes, key: str | bytes) -> dict[str, object]
PyJWT >=2.10,<3 is installed. The key is a trusted HS256 secret. Return decoded claims
only after authenticating the signature and checking the fixed policy. Use PyJWT's
standard exceptions for invalid signatures, algorithms, issuer, audience, expiry
and missing required claims. Do not access a network or environment configuration.
""",
    "bound-concurrent-work": """
Public signature:
    async def consume_bounded[T](
        source: AsyncIterable[T], handle: Callable[[T], Awaitable[None]],
        *, concurrency: int, buffer_size: int,
    ) -> None
Use only the Python standard library. Invalid nonpositive limits raise ValueError
with a message containing "must be positive", before source or handler work begins.
Both source and handler are cooperative with asyncio cancellation. Never close the
caller-owned source. Both direct and grouped ordinary failures are acceptable.
""",
    "coalesce-cache-misses": """
Public interface:
    class SingleFlight[K: Hashable, V]:
        def __init__(self) -> None: ...
        async def get(self, key: K, load: Callable[[], Coroutine[object, object, V]]) -> V: ...
        async def close(self) -> None: ...
Use only the Python standard library. One instance belongs to one event loop.
The helper shares in-flight loads, not completed cached values. Propagate loader
errors to waiters, and allow a later get to retry a failed load. Callers stop new
admission before close; loaders have their own deadlines and do not recursively
request their own key. close may cancel or drain work, but must join all owned
tasks and their cooperative cleanup before returning.
""",
}


def digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def main() -> None:
    if (OUT / "manifest.json").exists():
        raise FileExistsError("Pilot already prepared")
    context = OUT / "build"
    context.mkdir(exist_ok=True)
    snapshot = context / "project"
    snapshot.mkdir(exist_ok=True)
    for name in ("src", "examples", "tests", "evals", "skills"):
        shutil.copytree(
            ROOT / name,
            snapshot / name,
            ignore=shutil.ignore_patterns("__pycache__"),
            dirs_exist_ok=True,
        )
    for name in ("pyproject.toml", "uv.lock", "README.md", "LICENSE", "LICENSE-DOCS.md"):
        shutil.copyfile(ROOT / name, snapshot / name)
    hashes = {
        str(path.relative_to(snapshot)): digest(path.read_bytes())
        for path in sorted(snapshot.rglob("*"))
        if path.is_file()
    }
    rows = (ROOT / "evals/contracts.md").read_text().splitlines()
    schedule = []
    rng = random.Random(20261116)
    for repeat in (1, 2):
        tasks = list(TASKS)
        rng.shuffle(tasks)
        for task_index, task in enumerate(tasks):
            conditions = ["unguided", "guided"]
            if (TASKS.index(task) + repeat) % 2 == 0:
                conditions.reverse()
            for condition in conditions:
                run_id = f"{len(schedule) + 1:02d}-{task}-r{repeat}-{condition}"
                directory = OUT / "runs" / run_id
                directory.mkdir(parents=True, exist_ok=True)
                contract = next(line for line in rows if line.startswith(f"| {task} |"))
                contract = "# Task contract\n\n" + contract.split(" | ", 1)[1].removesuffix(" |")
                contract += "\n\n" + DETAILS[task].strip() + "\n"
                guide = ROOT / "src/python_backend_guidance/guides" / f"{task}.md"
                guidance = (
                    guide.read_text()
                    if condition == "guided"
                    else "# Supporting material\n\nNo additional guidance is supplied.\n"
                )
                config = {
                    "$schema": "https://opencode.ai/config.json",
                    "default_agent": "pbg-pilot",
                    "snapshots": False,
                    "formatter": False,
                    "warming": False,
                    "agents": {
                        "pbg-pilot": {
                            "description": "Implement one isolated evaluation contract",
                            "mode": "primary",
                            "model": MODEL,
                            "system": SYSTEM,
                            "steps": 8,
                            "permissions": [
                                {"action": "*", "resource": "*", "effect": "deny"},
                                *[
                                    {"action": "read", "resource": name, "effect": "allow"}
                                    for name in ("CONTRACT.md", "GUIDANCE.md", "solution.py")
                                ],
                                {"action": "edit", "resource": "solution.py", "effect": "allow"},
                            ],
                        }
                    },
                }
                files = {
                    "CONTRACT.md": contract,
                    "GUIDANCE.md": guidance,
                    "opencode.json": json.dumps(config, indent=2) + "\n",
                }
                for name, content in files.items():
                    (directory / name).write_text(content)
                schedule.append({
                    "id": run_id,
                    "task": task,
                    "repeat": repeat,
                    "condition": condition,
                    "directory": str(directory),
                    "input_sha256": {name: digest(text.encode()) for name, text in files.items()},
                })
    manifest = {
        "schema_version": 1,
        "kind": "direct-guide-agent-pilot",
        "model": MODEL,
        "agent": "pbg-pilot",
        "opencode_version": "2.3.0",
        "wall_timeout_seconds": 300,
        "max_model_steps": 8,
        "max_runs": 12,
        "retries": 0,
        "seed": 20261116,
        "prompt": PROMPT,
        "system": SYSTEM,
        "global_instructions_sha256": digest(
            Path("/home/yuwisasha/.config/opencode/AGENTS.md").read_bytes()
        ),
        "source_sha256": hashes,
        "schedule": schedule,
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (OUT / "prompt.txt").write_text(PROMPT)
    print("Prepared", len(schedule), "trials; no model calls made.")
    print("First trial:", schedule[0]["directory"])


if __name__ == "__main__":
    main()
