"""Audit completed trial evidence and produce descriptive, paired pilot results."""

import hashlib
import json
import statistics
import tarfile
from collections import Counter
from pathlib import Path

OUT = Path(__file__).parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    manifest = json.loads((OUT / "manifest.json").read_text())
    results = []
    for trial in manifest["schedule"]:
        directory = Path(trial["directory"])
        result = json.loads((directory / "result.json").read_text())
        for name, expected in trial["input_sha256"].items():
            assert digest(directory / name) == expected
        if "solution_sha256" in result:
            assert digest(directory / "solution.py") == result["solution_sha256"]
        messages = json.loads((directory / "transcript.json").read_text())["data"]["messages"]
        calls = []
        for message in messages:
            if message["type"] != "assistant":
                continue
            assert message["model"] == {
                "id": "gpt-6.1-sol", "providerID": "openai", "variant": "medium"
            }
            assert message["agent"] == manifest["agent"]
            calls.extend(part for part in message["content"] if part["type"] == "tool")
        result["tool_counts"] = dict(Counter(call["name"] for call in calls))
        result["tool_errors"] = [
            {"name": call["name"], "state": call["state"]["status"]}
            for call in calls if call["state"]["status"] != "completed"
        ]
        assert {
            call["name"] for call in calls if call["state"]["status"] == "completed"
        } <= {"read", "patch", "write", "edit"}
        result["full_contract_passed"] = (
            result["agent_exit_code"] == 0
            and not result["timed_out"]
            and (result["grade"] or {}).get("status") == "passed"
        )
        results.append(result)
    assert len(results) == 12
    assert len({result["session_id"] for result in results}) == 12
    summaries = {}
    for condition in ("unguided", "guided"):
        rows = [row for row in results if row["condition"] == condition]
        summaries[condition] = {
            "runs": len(rows),
            "full_contract_passes": sum(row["full_contract_passed"] for row in rows),
            "mean_elapsed_seconds": round(statistics.mean(row["elapsed_seconds"] for row in rows), 3),
            "median_elapsed_seconds": round(statistics.median(row["elapsed_seconds"] for row in rows), 3),
            "tokens_reported": {
                **{key: sum(row["tokens"][key] for row in rows) for key in ("input", "output", "reasoning")},
                "cache_read": sum(row["tokens"]["cache"]["read"] for row in rows),
                "cache_write": sum(row["tokens"]["cache"]["write"] for row in rows),
            },
            "tool_errors": sum(len(row["tool_errors"]) for row in rows),
            "agent_errors": sum(row["agent_exit_code"] != 0 or row["timed_out"] for row in rows),
            "checks": dict(sum((Counter((row["grade"] or {}).get("summary", {})) for row in rows), Counter())),
        }
    pairs = []
    for task in ("bound-concurrent-work", "coalesce-cache-misses", "verify-token-claims"):
        for repeat in (1, 2):
            pair = {row["condition"]: row for row in results if row["task"] == task and row["repeat"] == repeat}
            pairs.append({
                "task": task, "repeat": repeat,
                "unguided_passed": pair["unguided"]["full_contract_passed"],
                "guided_passed": pair["guided"]["full_contract_passed"],
                "guided_minus_unguided_seconds": round(pair["guided"]["elapsed_seconds"] - pair["unguided"]["elapsed_seconds"], 3),
            })
    report = {
        "report_schema": 1,
        "kind": manifest["kind"],
        "model": manifest["model"],
        "opencode_version": manifest["opencode_version"],
        "wall_timeout_seconds": manifest["wall_timeout_seconds"],
        "max_model_steps": manifest["max_model_steps"],
        "manifest_sha256": digest(OUT / "manifest.json"),
        "snapshot_file_hashes": manifest["source_sha256"],
        "conditions": summaries,
        "pairs": pairs,
        "guided_only_passes": sum(pair["guided_passed"] and not pair["unguided_passed"] for pair in pairs),
        "unguided_only_passes": sum(pair["unguided_passed"] and not pair["guided_passed"] for pair in pairs),
        "monetary_cost_usd": None,
        "monetary_cost_reason": "Provider returned no tariffs; recorded zero costs are not verified billing.",
        "trials": results,
    }
    (OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    with tarfile.open(OUT / "evidence.tar.gz", "w:gz") as archive:
        for name in ("manifest.json", "prompt.txt", "prepare.py", "run_trials.py", "summarize.py", "Dockerfile", "build", "results.json"):
            archive.add(OUT / name, arcname=name)
        for trial in manifest["schedule"]:
            directory = Path(trial["directory"])
            for name in ("CONTRACT.md", "GUIDANCE.md", "opencode.json", "started.json", "session.json", "solution.py", "result.json", "transcript.json"):
                path = directory / name
                if path.is_file():
                    archive.add(path, arcname=f"runs/{trial['id']}/{name}")
    print(json.dumps({key: report[key] for key in ("conditions", "pairs", "guided_only_passes", "unguided_only_passes")}, indent=2))
    print("Evidence archive SHA256:", digest(OUT / "evidence.tar.gz"))


if __name__ == "__main__":
    main()
