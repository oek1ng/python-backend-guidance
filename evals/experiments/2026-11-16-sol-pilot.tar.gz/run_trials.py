"""Run only the predeclared trial numbers; never retry a started model run."""

import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).parent
IMAGE = "sha256:55abbe5e2b9b5b9a21645a4ce9d671d39aebc4c0150738c2a0fd147376a85ee5"


def api(method: str, path: str, body: object = None) -> dict:
    command = ["opencode", "api", method, path]
    if body is not None:
        command.extend(["--data", json.dumps(body)])
    result = subprocess.run(command, capture_output=True, text=True, timeout=30, check=True)
    return json.loads(result.stdout) if result.stdout.strip() else {}


def run(number: int) -> None:
    manifest = json.loads((OUT / "manifest.json").read_text())
    assert 1 <= number <= manifest["max_runs"]
    trial = manifest["schedule"][number - 1]
    directory = Path(trial["directory"])
    for name, expected in trial["input_sha256"].items():
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected
    session_file = directory / "session.json"
    if session_file.exists():
        session = json.loads(session_file.read_text())
    else:
        session = api("post", "/api/session", {
            "title": "PBG pilot " + trial["id"],
            "agent": manifest["agent"],
            "model": {"providerID": "openai", "id": "gpt-6.1-sol", "variant": "medium"},
            "location": {"directory": str(directory)},
        })["data"]
        session_file.write_text(json.dumps(session, indent=2) + "\n")
    command = [
        "opencode", "--standalone", "run",
        "--session", session["id"],
        "--agent", manifest["agent"],
        "--model", manifest["model"],
        "--format", "json",
        "--title", "PBG pilot " + trial["id"],
        manifest["prompt"],
    ]
    with (directory / "started.json").open("x") as record:
        json.dump({"started_at": time.time(), "command": command}, record, indent=2)
    environment = dict(os.environ)
    environment.pop("OPENCODE_SESSION_ID", None)
    started = time.monotonic()
    timed_out = False
    with (directory / "events.ndjson").open("w") as stdout, (directory / "agent.stderr").open("w") as stderr:
        process = subprocess.Popen(
            command, cwd=directory, env=environment,
            stdout=stdout, stderr=stderr, start_new_session=True,
        )
        try:
            exit_code = process.wait(timeout=manifest["wall_timeout_seconds"])
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            exit_code = process.wait()
            api("post", f"/api/session/{session['id']}/interrupt", {})
    result = {
        "id": trial["id"],
        "task": trial["task"],
        "condition": trial["condition"],
        "repeat": trial["repeat"],
        "session_id": session["id"],
        "model": manifest["model"],
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "agent_exit_code": exit_code,
        "timed_out": timed_out,
        "grade": None,
    }
    info = api("get", f"/api/session/{session['id']}")["data"]
    result["session_outcome"] = info.get("outcome")
    result["tokens"] = info["tokens"]
    result["reported_cost_usd"] = info["cost"]
    result["cost_status"] = "unpriced-provider; reported zero is not verified free usage"
    solution = directory / "solution.py"
    if exit_code == 0 and not timed_out and solution.is_file() and not solution.is_symlink():
        result["solution_sha256"] = hashlib.sha256(solution.read_bytes()).hexdigest()
        name = "pbg-sol-grade-" + trial["id"].split("-")[0]
        command = [
            "docker", "run", "--rm", "--name", name,
            "--network", "none", "--read-only", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--pids-limit", "64",
            "--memory", "512m", "--cpus", "1",
            "--tmpfs", "/tmp:rw,nosuid,nodev,size=64m",
            "--mount", f"type=bind,src={solution},dst=/candidate/solution.py,readonly",
            IMAGE, "python", "-m", "evals.run", "grade",
            "--task", trial["task"], "--solution", "/candidate/solution.py",
            "--allow-code-execution",
        ]
        try:
            graded = subprocess.run(command, capture_output=True, text=True, timeout=45)
            (directory / "grade.stdout").write_text(graded.stdout)
            (directory / "grade.stderr").write_text(graded.stderr)
            result["grader_exit_code"] = graded.returncode
            try:
                grade = json.loads(graded.stdout)
            except json.JSONDecodeError:
                grade = {"status": "infrastructure-error"}
            result["grade"] = grade
        except subprocess.TimeoutExpired:
            subprocess.run(["docker", "rm", "--force", name], capture_output=True, check=False)
            result["grade"] = {"status": "timeout"}
    exported = api("get", f"/api/experimental/session/{session['id']}/export?sanitize=true")
    (directory / "transcript.json").write_text(json.dumps(exported, indent=2) + "\n")
    api("patch", f"/api/session/{session['id']}", {"archived": True})
    (directory / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        trial["id"], "agent=", exit_code, "seconds=", result["elapsed_seconds"],
        "grade=", (result["grade"] or {}).get("status", "not-run"), flush=True,
    )


if __name__ == "__main__":
    for argument in sys.argv[1:]:
        run(int(argument))
