"""Application policy: two-decimal, half-even checkout prices."""

from decimal import ROUND_HALF_EVEN, Context, Decimal, InvalidOperation, localcontext


def invoice_total(lines: list[tuple[str, int]]) -> Decimal:
    total_cents = 0
    with localcontext(Context(prec=28, rounding=ROUND_HALF_EVEN)):
        for price, quantity in lines:
            if not isinstance(price, str) or len(price) > 64:
                raise ValueError("invalid price")
            if type(quantity) is not int or not 1 <= quantity <= 1000:
                raise ValueError("invalid quantity")
            try:
                amount = Decimal(price)
            except InvalidOperation as error:
                raise ValueError("invalid price") from error
            if not amount.is_finite() or amount.copy_abs() > Decimal("1000000000"):
                raise ValueError("invalid price")
            unit_price = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
            total_cents += int(unit_price * 100) * quantity

    # Integer accumulation remains exact regardless of the invoice length.
    sign, digits, _ = Decimal(total_cents).as_tuple()
    return Decimal((sign, digits, -2))
