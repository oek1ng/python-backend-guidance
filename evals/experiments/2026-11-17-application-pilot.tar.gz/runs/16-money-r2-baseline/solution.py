"""Application policy: a defective float-based checkout calculator."""

from decimal import Context, Decimal, InvalidOperation, ROUND_HALF_EVEN, localcontext


def invoice_total(lines: list[tuple[str, int]]) -> Decimal:
    # Allow enough precision for the largest possible sum, including cents.
    context = Context(
        prec=32 + len(str(len(lines))),
        rounding=ROUND_HALF_EVEN,
        traps=[InvalidOperation],
    )
    with localcontext(context):
        total = Decimal("0.00")
        for price, quantity in lines:
            if not isinstance(price, str) or len(price) > 64:
                raise ValueError("invalid price")
            if type(quantity) is not int or not 1 <= quantity <= 1000:
                raise ValueError("invalid quantity")
            try:
                amount = Decimal(price)
            except InvalidOperation as exc:
                raise ValueError("invalid price") from exc
            if not amount.is_finite() or amount.copy_abs() > Decimal("1000000000"):
                raise ValueError("invalid price")
            total += amount.quantize(Decimal("0.01")) * quantity
        return total
