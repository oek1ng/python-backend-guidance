"""Application workflow: a bounded, concurrent inventory import."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable


async def sync_inventory[T](
    records: AsyncIterable[T],
    persist: Callable[[T], Awaitable[None]],
    *,
    workers: int,
    pending: int,
) -> int:
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 1
        for value in (workers, pending)
    ):
        raise ValueError("workers and pending must be positive integers")

    queue: asyncio.Queue[T] = asyncio.Queue(maxsize=pending)
    completed = 0

    async def worker() -> None:
        nonlocal completed
        while True:
            record = await queue.get()
            try:
                await persist(record)
                completed += 1
            finally:
                queue.task_done()

    async with asyncio.TaskGroup() as group:
        tasks = [group.create_task(worker()) for _ in range(workers)]
        async for record in records:
            await queue.put(record)
        await queue.join()
        for task in tasks:
            task.cancel()

    return completed
