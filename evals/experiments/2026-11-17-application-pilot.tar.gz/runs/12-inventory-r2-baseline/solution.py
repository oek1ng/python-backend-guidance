"""Application workflow: a bounded, concurrent inventory import."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable


async def sync_inventory[T](
    records: AsyncIterable[T],
    persist: Callable[[T], Awaitable[None]],
    *,
    workers: int,
    pending: int,
) -> int:
    if (
        not isinstance(workers, int)
        or isinstance(workers, bool)
        or workers < 1
        or not isinstance(pending, int)
        or isinstance(pending, bool)
        or pending < 1
    ):
        raise ValueError("workers and pending must be positive integers")

    queue: asyncio.Queue[tuple[T] | None] = asyncio.Queue(maxsize=pending)
    completed = 0

    async def worker() -> None:
        nonlocal completed
        while True:
            item = await queue.get()
            if item is None:
                return
            await persist(item[0])
            completed += 1

    async with asyncio.TaskGroup() as group:
        for _ in range(workers):
            group.create_task(worker())
        async for record in records:
            await queue.put((record,))
        for _ in range(workers):
            await queue.put(None)

    return completed
