"""Application policy: a defective float-based checkout calculator."""

from decimal import ROUND_HALF_EVEN, Context, Decimal, InvalidOperation, localcontext


def invoice_total(lines: list[tuple[str, int]]) -> Decimal:
    total_cents = 0
    policy = Context(
        prec=28, rounding=ROUND_HALF_EVEN, Emin=-999999, Emax=999999,
        traps=[InvalidOperation],
    )
    with localcontext(policy):
        for price, quantity in lines:
            if not isinstance(price, str) or len(price) > 64:
                raise ValueError("invalid price")
            if (
                not isinstance(quantity, int)
                or isinstance(quantity, bool)
                or not 1 <= quantity <= 1000
            ):
                raise ValueError("invalid quantity")
            try:
                amount = Decimal(price)
                if not amount.is_finite() or amount.copy_abs() > Decimal("1000000000"):
                    raise ValueError("invalid price")
                rounded = amount.quantize(Decimal("0.01"))
            except InvalidOperation as error:
                raise ValueError("invalid price") from error
            total_cents += int(rounded * 100) * quantity
    parts = Decimal(total_cents).as_tuple()
    return Decimal((parts.sign, parts.digits, -2))
