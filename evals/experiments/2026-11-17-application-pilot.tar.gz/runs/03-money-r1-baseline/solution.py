"""Application policy: a defective float-based checkout calculator."""

import re
from decimal import Decimal


def invoice_total(lines: list[tuple[str, int]]) -> Decimal:
    total_cents = 0
    for price, quantity in lines:
        if not isinstance(price, str) or len(price) > 64:
            raise ValueError("invalid price")
        match = re.fullmatch(
            r"([+-]?)([0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE]([+-]?[0-9]+))?",
            price,
        )
        if match is None:
            raise ValueError("invalid price")
        if type(quantity) is not int or not 1 <= quantity <= 1000:
            raise ValueError("invalid quantity")
        sign, mantissa, exponent = match.groups()
        whole, _, fraction = mantissa.partition(".")
        digits = (whole + fraction).lstrip("0")
        if not digits:
            continue
        scale = int(exponent or "0") - len(fraction)

        # Compare the exact, unrounded amount with 10**9.
        width = len(digits) + scale
        if width > 10 or (
            width == 10 and (digits[0] != "1" or any(c != "0" for c in digits[1:]))
        ):
            raise ValueError("invalid price")

        # Work in integer cents, including HALF_EVEN ties. Avoid constructing
        # enormous powers of ten for valid prices with very small exponents.
        shift = scale + 2
        if shift >= 0:
            cents = int(digits) * 10**shift
        elif -shift > len(digits):
            cents = 0
        else:
            divisor = 10**(-shift)
            cents, remainder = divmod(int(digits), divisor)
            if remainder * 2 > divisor or (
                remainder * 2 == divisor and cents % 2
            ):
                cents += 1
        total_cents += (-cents if sign == "-" else cents) * quantity
    return Decimal(
        (int(total_cents < 0), tuple(map(int, str(abs(total_cents)))), -2)
    )
