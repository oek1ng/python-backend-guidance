"""Application workflow: an inventory import with bounded concurrent work."""

import asyncio
from collections.abc import AsyncIterable, Awaitable, Callable


async def sync_inventory[T](
    records: AsyncIterable[T],
    persist: Callable[[T], Awaitable[None]],
    *,
    workers: int,
    pending: int,
) -> int:
    if any(
        isinstance(value, bool) or not isinstance(value, int) or value < 1
        for value in (workers, pending)
    ):
        raise ValueError("workers and pending must be positive integers")

    # Wrapping records keeps None available as an unambiguous stop marker.
    queue: asyncio.Queue[tuple[T] | None] = asyncio.Queue(maxsize=pending)
    completed = 0

    async def worker() -> None:
        nonlocal completed
        while True:
            item = await queue.get()
            if item is None:
                return
            await persist(item[0])
            completed += 1

    async with asyncio.TaskGroup() as group:
        for _ in range(workers):
            group.create_task(worker())

        async for record in records:
            await queue.put((record,))

        for _ in range(workers):
            await queue.put(None)

    return completed
